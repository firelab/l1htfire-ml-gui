#Config for ml web_app
SECRET_KEY = 'dfjINl!43&Kdfndla*lkn_dl2dsgdHrsd^5H9>46#c*5N'